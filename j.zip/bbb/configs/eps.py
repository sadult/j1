# Telegram
TOKEN = '2134800716:AAHmUFCquhoSWRFYnWYTIMKud-AIZWm3HyA'
BOT_USERNAME = 'test2901834bot'
SUDO = 2044016267

# Coin/Token
NETWORK = 'ethereum'
TOKEN_NAME = 'Libarty Share Token'
SYMBOL = 'lst'
SYMBOL_UPPER = 'LST'
CONTRACT = '0x355376d6471e09a4ffca8790f50da625630c5270'
AIRDROP_SUPPLY = '1,000,000'
REGISTER_REWARD = '1000'
REFERRAL_REWARD = '200'
CURRENT_PRICE = '0.068'

# Channels
CHANNEL1 = 'LST_Token'
WITHDRAW_Channel = ''
# CHANNEL2 = 'Bull_Premium'
# CHANNEL3 = 'NPOWithdraw'
# CHANNEL3 = 'NPODeposit'

# Twitter account's
TWITTER = 'Libartyshareto1'
WITHDRAW_OPENING = '15 January'

# Our wallets
USDT_WALLET = 'TXYEnQGVaXcL3CmtaLRdyd2Q4Y5zXzPGus'
BNB_WALLET = 'bnb1v9muu5605dk5amzxpnf4tvad4sjuevdwf8peav'
BUSD_WALLET = '0x3A01428ecA81b945cA8893f334F0D9C7b9890901'
TRX_WALLET =  'TXYEnQGVaXcL3CmtaLRdyd2Q4Y5zXzPGus'
